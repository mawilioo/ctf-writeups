#!/usr/bin/env python3
"""
BrainDuck interpreter.

BrainDuck is a duck-themed esoteric language.  A program is a flat list of
whitespace-separated tokens.  Most tokens are "duck words" (QUACK, WADDLE, ...)
that map to a single operation on an 8-bit memory tape, a pointer and a stack.

Run it like this:

    python3 brainduck.py program.bd

The program will ask for a flag and tell you whether the duck is enlightened.

Nothing here uses eval/exec - it is a plain dispatch loop.  The pond is calm.
"""

import sys

# --- machine constants -------------------------------------------------------
TAPE_SIZE = 256          # the duck has a short memory
CELL_MASK = 0xFF         # 8-bit cells, because ducks count on their toes
MAX_STEPS = 5_000_000    # ponds are big but not infinite


class BrainDuckError(Exception):
    """Raised for malformed programs.  Callers turn this into a calm failure."""


# --- bit helpers (a duck spins on the water) ---------------------------------
def rol8(v, r):
    r &= 7
    return ((v << r) | (v >> (8 - r))) & CELL_MASK


def ror8(v, r):
    r &= 7
    return ((v >> r) | (v << (8 - r))) & CELL_MASK


# --- the instruction set -----------------------------------------------------
# canonical opcodes and whether they consume an operand.
#   'num'   -> a decimal integer operand
#   'lbl'   -> a label-name operand
#   None    -> no operand
OPCODES = {
    "WADDLE": None,   # ptr += 1   (waddle to the right)
    "MIGRATE": None,  # ptr -= 1   (migrate back to the left)
    "PECK": None,     # cell += 1
    "HONK": None,     # cell -= 1
    "BREAD": "num",   # cell += n  (feed the duck)
    "FLAP": "num",    # cell -= n
    "SPLASH": "num",  # cell ^= n  (a splash mixes things up)
    "SWIM": "num",    # cell = rol8(cell, n)
    "PADDLE": "num",  # cell = ror8(cell, n)
    "EGG": None,      # read one input byte into cell (lay an egg)
    "QUACK": "num",   # compare cell with n, set the zero flag
    "HATCH": "lbl",   # jump if equal     (the egg hatches)
    "SCATTER": "lbl", # jump if not equal (ducklings scatter)
    "FLY": "lbl",     # unconditional jump
    "NEST": None,     # loop start: if cell == 0 skip past matching POND
    "POND": None,     # loop end:   if cell != 0 jump back after matching NEST
    "FEATHER": None,  # push cell to the stack
    "MOLT": None,     # pop stack into cell
    "DUCK": None,     # success terminator
    "ROTTEN": None,   # failure terminator (a rotten egg)
    "ROOST": None,    # halt with no verdict (the duck goes to sleep)
    "PREEN": None,    # no-op (the duck preens its feathers)
}

# A handful of symbol aliases.  encode_program.py sprinkles these in to make the
# pond muddier; the lexer normalises them straight back to canonical opcodes.
ALIASES = {
    ">": "WADDLE",
    "<": "MIGRATE",
    "+": "PECK",
    "-": "HONK",
    "*": "PREEN",
}


class Instr:
    __slots__ = ("op", "arg")

    def __init__(self, op, arg=None):
        self.op = op
        self.arg = arg

    def __repr__(self):
        return f"{self.op}" + (f" {self.arg}" if self.arg is not None else "")


class Program:
    def __init__(self, instrs, labels, matches):
        self.instrs = instrs      # list[Instr]
        self.labels = labels      # name -> instruction index
        self.matches = matches    # NEST index <-> POND index


# --- lexing / parsing --------------------------------------------------------
def _tokens(text):
    """Yield bare tokens, dropping '#' comments and all whitespace noise."""
    for line in text.splitlines():
        code = line.split("#", 1)[0]
        for tok in code.split():
            yield tok


def parse(text):
    """Turn source text into a Program.  Raises BrainDuckError on junk."""
    raw = list(_tokens(text))
    instrs = []
    labels = {}

    i = 0
    n = len(raw)
    while i < n:
        tok = raw[i]
        i += 1

        # a label definition looks like "name:"
        if tok.endswith(":") and len(tok) > 1:
            name = tok[:-1]
            labels[name] = len(instrs)
            continue

        op = ALIASES.get(tok, tok)
        if op not in OPCODES:
            raise BrainDuckError(f"unknown token: {tok!r}")

        kind = OPCODES[op]
        if kind is None:
            instrs.append(Instr(op))
            continue

        if i >= n:
            raise BrainDuckError(f"{op} expects an operand but the pond ran dry")
        operand = raw[i]
        i += 1
        if kind == "num":
            try:
                instrs.append(Instr(op, int(operand) & CELL_MASK))
            except ValueError:
                raise BrainDuckError(f"{op} wanted a number, got {operand!r}")
        else:  # 'lbl'
            instrs.append(Instr(op, operand))

    # resolve label operands and pre-match NEST/POND pairs.
    matches = {}
    stack = []
    for idx, ins in enumerate(instrs):
        if ins.op in ("HATCH", "SCATTER", "FLY"):
            if ins.arg not in labels:
                raise BrainDuckError(f"jump to unknown label {ins.arg!r}")
        elif ins.op == "NEST":
            stack.append(idx)
        elif ins.op == "POND":
            if not stack:
                raise BrainDuckError("POND without a matching NEST")
            start = stack.pop()
            matches[start] = idx
            matches[idx] = start
    if stack:
        raise BrainDuckError("NEST without a matching POND")

    return Program(instrs, labels, matches)


# --- execution ---------------------------------------------------------------
def run(program, input_bytes):
    """
    Execute a parsed Program against the given input bytes.
    Returns True if the program reached DUCK (success), else False.
    """
    tape = bytearray(TAPE_SIZE)
    ptr = 0
    stack = []
    zero_flag = False
    ip = 0
    inp = list(input_bytes)
    in_pos = 0
    steps = 0

    instrs = program.instrs
    labels = program.labels
    matches = program.matches
    n = len(instrs)

    while 0 <= ip < n:
        steps += 1
        if steps > MAX_STEPS:
            raise BrainDuckError("the duck swam in circles for too long")

        ins = instrs[ip]
        op = ins.op
        arg = ins.arg

        if op == "WADDLE":
            ptr += 1
            if ptr >= TAPE_SIZE:
                raise BrainDuckError("waddled off the edge of the pond")
        elif op == "MIGRATE":
            ptr -= 1
            if ptr < 0:
                raise BrainDuckError("migrated off the edge of the pond")
        elif op == "PECK":
            tape[ptr] = (tape[ptr] + 1) & CELL_MASK
        elif op == "HONK":
            tape[ptr] = (tape[ptr] - 1) & CELL_MASK
        elif op == "BREAD":
            tape[ptr] = (tape[ptr] + arg) & CELL_MASK
        elif op == "FLAP":
            tape[ptr] = (tape[ptr] - arg) & CELL_MASK
        elif op == "SPLASH":
            tape[ptr] = (tape[ptr] ^ arg) & CELL_MASK
        elif op == "SWIM":
            tape[ptr] = rol8(tape[ptr], arg)
        elif op == "PADDLE":
            tape[ptr] = ror8(tape[ptr], arg)
        elif op == "EGG":
            # lay an egg: next input byte, or 0 once the input is exhausted.
            if in_pos < len(inp):
                tape[ptr] = inp[in_pos] & CELL_MASK
            else:
                tape[ptr] = 0
            in_pos += 1
        elif op == "QUACK":
            zero_flag = (tape[ptr] == arg)
        elif op == "HATCH":
            if zero_flag:
                ip = labels[arg]
                continue
        elif op == "SCATTER":
            if not zero_flag:
                ip = labels[arg]
                continue
        elif op == "FLY":
            ip = labels[arg]
            continue
        elif op == "NEST":
            if tape[ptr] == 0:
                ip = matches[ip] + 1
                continue
        elif op == "POND":
            if tape[ptr] != 0:
                ip = matches[ip] + 1
                continue
        elif op == "FEATHER":
            stack.append(tape[ptr])
        elif op == "MOLT":
            tape[ptr] = stack.pop() if stack else 0
        elif op == "PREEN":
            pass
        elif op == "DUCK":
            return True
        elif op == "ROTTEN":
            return False
        elif op == "ROOST":
            return False
        else:  # pragma: no cover - parse() already rejects unknown ops
            raise BrainDuckError(f"unhandled opcode {op!r}")

        ip += 1

    # ran off the end of the program without a verdict -> the duck is unmoved.
    return False


def evaluate(text, candidate):
    """
    Parse + run, swallowing BrainDuckError so malformed programs or wild input
    fail calmly instead of crashing.  `candidate` may be str or bytes.
    """
    if isinstance(candidate, str):
        candidate = candidate.encode("utf-8", "surrogatepass")
    try:
        program = parse(text)
        return run(program, candidate)
    except BrainDuckError:
        return False


# --- entry point -------------------------------------------------------------
def main(argv):
    if len(argv) != 2:
        print("usage: python3 brainduck.py program.bd")
        return 2

    try:
        with open(argv[1], "r", encoding="utf-8") as fh:
            source = fh.read()
    except OSError as exc:
        print(f"could not open program: {exc}")
        return 2

    print("Welcome to BrainDuck!")
    try:
        flag = input("Feed the duck a flag: ")
    except EOFError:
        flag = ""

    flag = flag.rstrip("\r\n")
    if evaluate(source, flag):
        print("Correct! The duck is enlightened.")
        return 0
    else:
        print("Wrong! The duck forgot how to quack.")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
