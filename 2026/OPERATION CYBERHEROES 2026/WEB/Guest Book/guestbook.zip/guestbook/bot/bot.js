const express = require('express');
const rateLimit = require('express-rate-limit');
const puppeteer = require('puppeteer');
const { URL } = require('url');
const { loadFlag } = require('./flag');

const PORT = process.env.PORT || 3000;
const TARGET_HOST = process.env.TARGET_HOST || 'app';
const FLAG = loadFlag();

console.log(`Bot service starting. Flag loaded (${FLAG.length} chars).`);

const app = express();
app.use(express.json());

// 1 request per 10 seconds per source IP, as required for the "visit" endpoint.
const visitLimiter = rateLimit({
  windowMs: 10 * 1000,
  max: 1,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Rate limit exceeded. Only 1 request per 10 seconds allowed.' },
});

app.post('/visit', visitLimiter, async (req, res) => {
  const { url } = req.body || {};
  if (!url) {
    return res.status(400).json({ error: 'Missing "url" in request body.' });
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch (err) {
    return res.status(400).json({ error: 'Invalid URL.' });
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    return res.status(400).json({ error: 'Only http(s) URLs are allowed.' });
  }

  console.log(`Visiting reported URL: ${url}`);

  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });
    const page = await browser.newPage();

    await page.setCookie({
      name: 'session',
      value: FLAG,
      domain: TARGET_HOST,
      path: '/',
    });

    await page.goto(url, { waitUntil: 'networkidle2', timeout: 20000 });

    await new Promise((resolve) => setTimeout(resolve, 3000));

    res.json({ status: 'visited' });
  } catch (err) {
    console.error('Error visiting URL:', err.message);
    res.status(500).json({ error: 'Failed to visit URL.' });
  } finally {
    if (browser) {
      await browser.close();
    }
  }
});

app.listen(PORT, () => {
  console.log(`Bot service listening on port ${PORT}`);
});
