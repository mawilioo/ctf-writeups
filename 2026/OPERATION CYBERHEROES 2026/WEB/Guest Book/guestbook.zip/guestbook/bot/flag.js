const fs = require('fs');
const path = require('path');

function loadFlag() {
  if (process.env.FLAG) {
    return process.env.FLAG;
  }
  return fs.readFileSync(path.join(__dirname, 'FLAG'), 'utf8').trim();
}

module.exports = { loadFlag };
