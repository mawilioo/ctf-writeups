import os

import requests
from flask import Flask, redirect, render_template, request, url_for

app = Flask(__name__)

BOT_SERVICE_URL = os.environ.get("BOT_SERVICE_URL", "http://bot:3000/visit")

# In-memory guestbook. Resets whenever the app container restarts.
messages = []


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/submit", methods=["POST"])
def submit():
    name = request.form.get("name", "")
    message = request.form.get("message", "")
    messages.append({"name": name, "message": message})
    return redirect(url_for("view_messages"))


@app.route("/messages")
def view_messages():
    return render_template("messages.html", messages=messages)


@app.route("/report", methods=["GET"])
def report_form():
    return render_template("report.html", reported=False, error=None)


@app.route("/report", methods=["POST"])
def report_submit():
    url = request.form.get("url", "")
    error = None
    try:
        resp = requests.post(BOT_SERVICE_URL, json={"url": url}, timeout=30)
        if resp.status_code == 429:
            error = "Admin bot is busy right now, please try again shortly."
        elif resp.status_code >= 400:
            error = f"Admin bot rejected the report: {resp.text}"
    except requests.RequestException as exc:
        error = f"Could not reach admin bot: {exc}"
    return render_template("report.html", reported=(error is None), error=error)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
