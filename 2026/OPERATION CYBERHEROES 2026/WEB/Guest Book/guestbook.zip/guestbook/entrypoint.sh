#!/bin/sh
node /usr/src/app/bot/bot.js &
exec python3 /usr/src/app/app/app.py
