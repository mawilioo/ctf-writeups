import crypto from 'crypto';

// ponytail: INTENTIONALLY BUGGY — CTF challenge vulnerability file

export default function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { username, password } = req.body || {};

  // Demo user — role is hardcoded to 'user', never 'admin'
  if (username === 'demo' && password === 'demo123') {
    const secret = process.env.API_SECRET;
    const payload = Buffer.from(JSON.stringify({ sub: username, role: 'user', iat: Date.now() })).toString('base64url');
    const sig = crypto.createHmac('sha256', secret).update(payload).digest('hex');
    return res.status(200).json({ token: `${payload}.${sig}` });
  }

  return res.status(401).json({ error: 'Invalid credentials' });
}
