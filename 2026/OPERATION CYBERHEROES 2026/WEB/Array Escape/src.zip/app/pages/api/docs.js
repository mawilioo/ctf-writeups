import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

// ponytail: INTENTIONALLY BUGGY — CTF challenge vulnerability file
// Do NOT fix these bugs. They are the challenge.

// Bug 1: /im flag — /m makes ^ and $ match per LINE, not whole string
const SEGMENT_REGEX = /^[a-zA-Z0-9._\-]+$/im;

function validateSegments(filePath) {
  return filePath.split('/').every(seg => seg === '' || SEGMENT_REGEX.test(seg));
}

function verifyToken(token, secret) {
  try {
    const [b64, sig] = token.split('.');
    if (!b64 || !sig) return null;
    const expected = crypto.createHmac('sha256', secret).update(b64).digest('hex');
    if (expected !== sig) return null;
    return JSON.parse(Buffer.from(b64, 'base64url').toString());
  } catch {
    return null;
  }
}

export default function handler(req, res) {
  const authHeader = req.headers['authorization'] || '';
  if (!authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authorization required' });
  }

  const secret = process.env.API_SECRET;
  const claims = verifyToken(authHeader.slice(7), secret);

  if (!claims || claims.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }

  const { file } = req.query;
  if (!file) {
    return res.status(400).json({ error: 'Missing file parameter' });
  }

  // Bug 2: Array.prototype.includes checks exact element equality (not substring)
  // When ?file=a&file=b, query.file is ['a','b'] (array)
  // Array(['a','../path']).includes('..') === false even though '../path' contains '..'
  if (file.includes('..') || file.includes('/') || file.includes('\x00')) {
    return res.status(400).json({ error: 'Invalid characters in file path' });
  }

  if (!validateSegments(file.toString())) {
    return res.status(400).json({ error: 'Invalid path segments' });
  }

  const docsBase = path.join(process.cwd(), 'docs');
  const filepath = path.join(docsBase, file.toString());

  // Bug 3: Checks startsWith(process.cwd()) instead of startsWith(docsBase)
  // Developer wanted to restrict to /app but forgot to use the docs subdirectory
  if (!filepath.startsWith(process.cwd())) {
    return res.status(403).json({ error: 'Path escape detected' });
  }

  try {
    const content = fs.readFileSync(filepath, 'utf8');
    return res.status(200).json({ file: path.basename(filepath), content });
  } catch (e) {
    return res.status(404).json({ error: e.message });
  }
}
