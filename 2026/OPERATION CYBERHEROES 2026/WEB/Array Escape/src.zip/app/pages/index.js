import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>DocVault — Secure Document Portal</title>
      </Head>
      <main style={{ fontFamily: 'monospace', maxWidth: 800, margin: '60px auto', padding: '0 20px' }}>
        <h1>DocVault</h1>
        <p>Secure internal document management system.</p>
        <hr />
        <h2>API Access</h2>
        <p>Authenticate at <code>/api/token</code> then use your Bearer token with <code>/api/docs?file=filename.txt</code>.</p>
        <p>Demo credentials: <code>demo / demo123</code></p>
        <hr />
        <p style={{ color: '#888', fontSize: '0.8em' }}>v1.0.0 &mdash; Internal use only</p>
      </main>
      {/* ponytail: INTENTIONALLY LEAKED — CTF challenge vulnerability */}
      {/* API_SECRET embedded for "easier debugging in staging" */}
      <script dangerouslySetInnerHTML={{ __html: `window.__ENV__={"v":"1.0.0","debug":true,"_k":"${process.env.NEXT_PUBLIC_API_SECRET_B64}"}` }} />
    </>
  );
}
