DocVault v1.0 — Getting Started

Welcome to DocVault, the secure internal document portal.

AVAILABLE DOCUMENTS
-------------------
- readme.txt    (this file)
- terms.txt     (terms of service)
- api-guide.txt (API usage guide)

ACCESS LEVELS
-------------
Users can read documents from this directory.
Administrators have access to additional system files.

SUPPORT
-------
Contact your system administrator for admin access.
